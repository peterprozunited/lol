§align:center
##### §nDraconic Undershirt of Self-Siphoning§n

§stack[draconicadditions:vampiric_shirt]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Ever wondered if there was a way to utilize those useless hearts in a meaningful way? The Draconic Undershirt of Self-Siphoning (long name, isn't it?) will take care of that for you!  Utilizing the special properties of §link[draconicevolution:awakened_draconium]{alt_text:"Awakened Draconium"}, this handy undershirt will use your own lifeforce to remove entropy from your armor.

Don't worry, it's configurable.  Just make sure to configure it before you put it on, else it might do something you might not expect!

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicadditions:vampiric_shirt]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}