§align:center
##### §nWyvern Shield Necklace§n

§stack[draconicadditions:wyvern_shield_necklace]{size:64}

The Wyvern Shield Necklace provides you with 8 shield points.  Just enough to help out in a pinch, but not enough to stop something like falling off a cliff!

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicadditions:wyvern_shield_necklace]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}