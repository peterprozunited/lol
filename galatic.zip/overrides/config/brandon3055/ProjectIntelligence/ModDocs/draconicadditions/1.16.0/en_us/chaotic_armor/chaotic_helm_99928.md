§align:center
##### §nChaotic Helmet§n

§stack[draconicadditions:chaotic_helm]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bStats

Immune to suffocation and drowning damage
Removes mining slowdown underwater (Aqua Affinity)
+120 Base Shield Capacity
+6 Armor Toughness
+6 Armor

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicadditions:chaotic_helm]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}