§align:center
##### §nPortable Wired Charger§n

§stack[draconicadditions:portable_wired_charger]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Portable Wired Chargers allow you to charge the items in your inventory by directly plugging it into your energy network.  Simply Shift-RightClick a side of the block you want to draw energy from, and if it's valid, you will attach to the network and start charging your inventory.  Any excess RF left over from extraction will be put back into the block, assuming it accepts energy on the side you're plugged into.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicadditions:portable_wired_charger]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}
§recipe[draconicadditions:portable_wired_charger,1,1]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}
§recipe[draconicadditions:portable_wired_charger,1,2]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}