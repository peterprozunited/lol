§align:center
##### §nCorrupted Dragon Heart§n

§entity[draconicadditions:chaosHeart]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
This item is dropped by Chaos Guardians when killed.  It's used in very few recipes, but the chaos contained within this heart can be extracted using a §link[draconicadditions:chaos_liquifier]{alt_text:"Chaos Liquefier"}.

Not much else to be said.
§rule{colour:0x606060,height:3,width:100%,top_pad:0}