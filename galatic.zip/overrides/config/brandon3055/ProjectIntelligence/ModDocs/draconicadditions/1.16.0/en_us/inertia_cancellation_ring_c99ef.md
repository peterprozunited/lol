§align:center
##### §nRing of Inertia Cancellation§n

§stack[draconicadditions:inertia_cancel_ring]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
The Ring of Inertia Cancellation allows you to quickly slow down when in creative mode style flight.  This functions exactly like the Draconic Chestplate (and Chaotic Chestplate), but can be used in combination with any other item that grants you flight.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicadditions:inertia_cancel_ring]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}