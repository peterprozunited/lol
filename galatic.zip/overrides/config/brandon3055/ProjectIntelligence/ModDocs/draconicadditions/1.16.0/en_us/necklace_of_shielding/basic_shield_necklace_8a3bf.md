§align:center
##### §nBasic Shield Necklace§n

§stack[draconicadditions:basic_shield_necklace]{size:64}

The Basic Shield Necklace provides you with 4 shield points, and isn't that great at recovering entropy.  However, where it shines is in its innate ability to use less RF to charge up your shield.  This makes it viable to get mid-game without having to break the bank to acquire it, but only good enough to stop the occasional zombie slap and skeleton arrow.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicadditions:basic_shield_necklace]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}