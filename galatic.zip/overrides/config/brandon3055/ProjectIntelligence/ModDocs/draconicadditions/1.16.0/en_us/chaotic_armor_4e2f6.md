§align:center
##### §nChaotic Armor§n

Chaotic Armor is a step up from Draconic Armor, designed to step up your post-post-end game to the next level!  However, it's not just a walk in the park to craft; you'll have to defeat multiple Chaos Guardians first!

You also might have to contend with a few limitations, though.  The chaos that runs rampant throughout this armor prevents you from being able to configure things you may be used to, but this is done for your own safety.  Other functions may also be hindered, so read carefully before fusing.

Once this chaos is stabilized, however, there may be §link[draconicadditions:chaotic_armor/chaotic_chest]{alt_text:"ways of using it"} that were previously unknown to you...