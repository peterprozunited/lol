§align:center
##### §nInfused Potato Helmet

§stack[draconicadditions:infused_potato_helm]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bStats

+1 Armor

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicadditions:infused_potato_helm]{spacing:4}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}